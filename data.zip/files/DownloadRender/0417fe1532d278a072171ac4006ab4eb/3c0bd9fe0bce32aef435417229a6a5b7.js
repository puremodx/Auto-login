import"./B47XiqZH.js";const t=""+new URL("image-1.apJjVir2.svg",import.meta.url).href;export{t as _};
