import{_ as t,x as c,f as n,bY as o}from"./B47XiqZH.js";const _={};function r(s,a){const e=o;return n(),c(e)}const p=t(_,[["render",r]]);export{p as default};
