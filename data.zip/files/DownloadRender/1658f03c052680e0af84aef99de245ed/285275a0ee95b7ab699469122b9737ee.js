const r="external-ad-resize",n=()=>{const t=new Uint32Array(4),e=globalThis.crypto;return e!=null&&e.getRandomValues?(e.getRandomValues(t),Array.from(t,i=>i.toString(36)).join("")):`${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`},o=(t,e)=>`
<script>
    (function () {
        var resizeScript = document.currentScript;
        var MESSAGE_TOKEN = '${e}';
        var lastHeight = 0;
        var notifyHeight = function () {
            var body = document.body;
            var doc = document.documentElement;
            var target = document.getElementById('container-b037dad9482fb50dde6e532f27e32465') || body;
            var rectHeight = target ? Math.ceil(target.getBoundingClientRect().height) : 0;
            var height = Math.ceil(Math.max(
                rectHeight,
                body ? body.scrollHeight : 0,
                doc ? doc.scrollHeight : 0
            ));

            if (height > 0 && height !== lastHeight) {
                lastHeight = height;
                window.parent.postMessage({
                    type: '${r}',
                    id: '${t}',
                    token: MESSAGE_TOKEN,
                    height: height
                }, '*');
            }
        };

        window.addEventListener('load', notifyHeight);
        new MutationObserver(notifyHeight).observe(document.documentElement, {
            attributes: true,
            childList: true,
            subtree: true
        });

        if ('ResizeObserver' in window) {
            new ResizeObserver(notifyHeight).observe(document.documentElement);
        }

        setInterval(notifyHeight, 500);
        notifyHeight();
        if (resizeScript && resizeScript.parentNode) {
            resizeScript.parentNode.removeChild(resizeScript);
        }
    })();
<\/script>`;export{r as A,o as a,n as c};
