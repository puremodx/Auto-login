import{c as y,a as v,A as k}from"./DjVE1iOU.js";import{d as m,r as l,o as x,e as E,y as h,z as d,Q as L,_,ak as b,a1 as g}from"./CQ4nBCVy.js";const B=["height"],f="banner",A=m({__name:"Banner",setup(w){const n=y(),s=l(50),o=l(null),r=`<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base target="_blank">
    <style>
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            overflow: hidden;
            background: transparent;
        }
        body {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
    ${v(f,n)}
    <script>
        (function () {
            var userClick = false;
            document.addEventListener('mousedown', function () { userClick = true; }, true);
            document.addEventListener('click', function () { userClick = true; }, true);
            var realLocation = window.top.location;
            Object.defineProperty(window.top, 'location', {
                get: function () { return realLocation; },
                set: function (v) { if (userClick) { realLocation.href = v; } userClick = false; },
                configurable: true
            });
        })();
    <\/script>
    <script>
        atOptions = {
            'key': '0128d756a3e16d6941a9b90c98189032',
            'format': 'iframe',
            'height': 50,
            'width': 320,
            'params': {}
        };
    <\/script>
    <script src="https://surlyplants.com/0128d756a3e16d6941a9b90c98189032/invoke.js"><\/script>
</body>
</html>`,u=t=>{var c;const e=t.data,a=(c=o.value)==null?void 0:c.contentWindow;return!!(e&&e.id===f&&e.token===n&&(!a||t.source===a))},i=t=>{const e=t.data;if(!(!e||!u(t))&&e.type===k){const a=Number(e.height);Number.isFinite(a)&&a>0&&(s.value=Math.ceil(a))}};return x(()=>{window.addEventListener("message",i)}),E(()=>{window.removeEventListener("message",i)}),(t,e)=>(d(),h("iframe",{ref_key:"adFrame",ref:o,class:"external-ad-frame",title:"Sponsored banner ad",height:L(s),srcdoc:r,"data-ad-id":f,sandbox:"allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation",loading:"lazy",referrerpolicy:"no-referrer-when-downgrade"},null,8,B))}}),C=_(A,[["__scopeId","data-v-c709a0e8"]]),M=["height"],p="native",N=m({__name:"Native",setup(w){const n=y(),s=l(1),o=l(null),r=`<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base target="_blank">
    <style>
        html, body {
            width: 100%;
            margin: 0;
        }
        body {
            display: flex;
            justify-content: center;
            color: #fff;
        }
        #container-b037dad9482fb50dde6e532f27e32465 {
            width: 100%;
            color: #fff;
        }
        #container-b037dad9482fb50dde6e532f27e32465 * {
            color: #fff !important;
        }
    </style>
</head>
<body>
    ${v(p,n)}
    <script>
        (function () {
            var userClick = false;
            document.addEventListener('mousedown', function () { userClick = true; }, true);
            document.addEventListener('click', function () { userClick = true; }, true);
            var realLocation = window.top.location;
            Object.defineProperty(window.top, 'location', {
                get: function () { return realLocation; },
                set: function (v) { if (userClick) { realLocation.href = v; } userClick = false; },
                configurable: true
            });
        })();
    <\/script>
    <script async="async" data-cfasync="false" src="https://surlyplants.com/b037dad9482fb50dde6e532f27e32465/invoke.js"><\/script>
    <div id="container-b037dad9482fb50dde6e532f27e32465"></div>
</body>
</html>`,u=t=>{var c;const e=t.data,a=(c=o.value)==null?void 0:c.contentWindow;return!!(e&&e.id===p&&e.token===n&&(!a||t.source===a))},i=t=>{const e=t.data;if(!(!e||!u(t))&&e.type===k){const a=Number(e.height);Number.isFinite(a)&&a>0&&(s.value=Math.ceil(a))}};return x(()=>{window.addEventListener("message",i)}),E(()=>{window.removeEventListener("message",i)}),(t,e)=>(d(),h("iframe",{ref_key:"adFrame",ref:o,class:"external-ad-frame",title:"Sponsored native ad",height:L(s),srcdoc:r,"data-ad-id":p,sandbox:"allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation",loading:"lazy",referrerpolicy:"no-referrer-when-downgrade"},null,8,M))}}),$=_(N,[["__scopeId","data-v-763b1a57"]]),F={class:"external-ads-sandbox"},S=m({__name:"sandboxExternal",props:{showBanner:{type:Boolean,default:!0},showNative:{type:Boolean,default:!0}},setup(w){return(n,s)=>{const o=C,r=$;return d(),h("section",F,[n.showBanner?(d(),b(o,{key:0})):g("",!0),n.showNative?(d(),b(r,{key:1})):g("",!0)])}}}),z=_(S,[["__scopeId","data-v-9a51e55c"]]);export{z as _,C as a};
